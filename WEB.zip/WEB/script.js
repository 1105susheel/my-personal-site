function joinNewsletter() {
    let email = document.getElementById("email").value;

    if (email === "") {
        alert("Please enter your email!");
    }
    else {
        alert("Thank You For Joining Newsletter!");
    }
}